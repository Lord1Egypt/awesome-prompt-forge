# Act as Agency Growth Bottleneck Identifier

Role & Goal
You are an experienced agency growth consultant. Build a single, cohesive “Growth Bottleneck Identifier” diagnostic framework tailored to my agency that pinpoints what’s blocking growth and tells me what to fix first.

Agency Snapshot (use these exact inputs)
- Agency type/niche: [YOUR AGENCY TYPE + NICHE]
- Primary offer(s): [SERVICE PACKAGES]
- Average delivery model: [DONE-FOR-YOU / COACHING / HYBRID]
- Current client count (active accounts): [ACTIVE ACCOUNTS]
- Team size (employees/contractors) + roles: [EMPLOYEES/CONTRACTORS + ROLES]
- Monthly revenue (MRR): [CURRENT MRR]
- Avg revenue per client (if known): [ARPC]
- Gross margin estimate (if known): [MARGIN %]
- Growth goal (90 days + 12 months): [TARGET CLIENTS/REVENUE + TIMEFRAME]
- Main complaint (what’s not working): [WHAT'S NOT WORKING]
- Biggest time drains (where hours go): [WHERE HOURS GO]
- Lead sources today: [REFERRALS / ADS / OUTBOUND / CONTENT / PARTNERS]
- Sales cycle + close rate (if known): [DAYS + %]
- Retention/churn (if known): [AVG MONTHS / %]

Output Requirements
Create ONE diagnostic system with:
1) A short overview: what the framework is and how to use it monthly (≤10 minutes/week).
2) A Scorecard (0–5 scoring) that covers all areas below, with clear scoring anchors for 0, 3, and 5.
3) A Calculation Section with formulas + worked examples using my inputs.
4) A Decision Tree that identifies the primary bottleneck (capacity, delivery/process, pricing, or lead flow).
5) A “Fix This First” prioritization engine that ranks issues by Impact × Effort × Risk, and outputs the top 3 actions for the next 14 days.
6) A simple dashboard summary at the end: Bottleneck → Evidence → First Fix → Expected Result.

Must-Include Diagnostic Modules (in this order)
A) Capacity Constraint Analysis (max client load)
- Determine current delivery capacity and maximum sustainable client load.
- Include a utilization formula based on hours available vs hours required per client.
- Output: current utilization %, max clients at current staffing, and “over/under capacity” flag.

B) Process Inefficiency Detector (wasted time)
- Identify top 5 recurring wastes mapped to: meetings, reporting, revisions, approvals, context switching, QA, comms, onboarding.
- Output: estimated hours/month recoverable + the specific process change(s) to reclaim them.

C) Hiring Need Calculator (when to add people)
- Translate growth goal into role-hours needed.
- Recommend the next hire(s) by role (e.g., account manager, specialist, ops, sales) with triggers:
  - “Hire when X happens” (utilization threshold, backlog threshold, SLA breaches, revenue threshold).
- Output: hiring timeline (Now / 30 days / 90 days) + expected capacity gained.

D) Tool/Automation Gap Identifier (what to automate)
- List the highest ROI automations for my time drains (e.g., intake forms, client comms templates, reporting, task routing, QA checklists).
- Output: automation shortlist with estimated hours saved/month and suggested tool category (not brand-dependent).

E) Pricing Problem Revealer (revenue per client)
- Compute revenue per client, delivery cost proxy, and “effective hourly rate.”
- Diagnose underpricing vs scope creep vs wrong packaging.
- Output: pricing moves (raise, repackage, tier, add performance fees, reduce inclusions) with clear criteria.

F) Lead Flow Bottleneck Finder (pipeline issues)
- Map pipeline stages: Lead → Qualified → Sales Call → Proposal → Close → Onboard.
- Identify the constraint stage using conversion math.
- Output: the single leakiest stage + 3 fixes (messaging, targeting, offer, follow-up, proof, outbound cadence).

G) “Fix This First” Prioritization (biggest impact)
- Use an Impact × Effort × Risk scoring table.
- Provide the top 3 fixes with:
  - exact steps,
  - owner (role),
  - time required,
  - success metric,
  - expected leading indicator in 7–14 days.

Quality Bar
- Keep it practical and numbers-driven.
- Use my inputs to produce real calculations (not placeholders) where possible; if an input is missing, state the assumption clearly and show how to replace it with the real number.
- Avoid generic advice; every recommendation must tie back to a scorecard result or calculation.
- Use plain language. No fluff.

Formatting
- Use clear headings for Modules A–G.
- Include tables for the Scorecard and the Prioritization engine.
- End with a 14-day action plan checklist.

Now generate the full diagnostic framework using the inputs provided above.
