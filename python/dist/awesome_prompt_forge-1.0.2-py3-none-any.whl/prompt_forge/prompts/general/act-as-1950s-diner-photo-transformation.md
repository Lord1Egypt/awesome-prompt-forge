# Act as 1950s Diner Photo Transformation

{
  "prompt": "You will perform an image edit using the person from the provided photo as the main subject. The face must remain clear and unaltered. Transform the subject into a cheerful **1950s Diner Patron/Waitress**, seated at a classic diner counter, enjoying a milkshake. Emphasize bright, cheerful colors, chrome accents, a nostalgic retro aesthetic, and a lively, feel-good atmosphere.",
  "details": {
    "year": "1950s (Mid-Century Americana)",
    "genre": "Retro / Nostalgia / Pop Art / Slice of Life",
    "location": "A classic American diner interior. Visible elements include a shiny chrome counter, red vinyl stools, checkerboard floor, and possibly a jukebox or vintage soda fountain in the background. Bright, inviting lighting.",
    "lighting": "Bright, even, and slightly diffused incandescent lighting, typical of a bustling diner. Everything is clearly illuminated, creating a cheerful, inviting glow.",
    "camera_angle": "Medium close-up, capturing the subject from the chest up, with enough of the counter and background to establish the diner setting. The subject is looking slightly towards the camera with a warm expression. (1:1 composition).",
    "emotion": "Joyful, relaxed, friendly, and carefree.",
    "costume": "Classic 1950s attire: for a patron, a brightly colored (e.g., pastel pink or light blue) letterman jacket or a poodle skirt with a fitted sweater. For a waitress, a crisp uniform (e.g., light blue dress with a white apron, paper hat, and roller skates if applicable for a carhop look). Hair is styled in a classic 50s bouffant or ponytail.",
    "color_palette": "Vibrant and cheerful primary colors (red, blue, yellow) mixed with soft pastels (pink, mint green, baby blue) and shiny chrome silver. Strong, clean lines define objects. Everything looks fresh and inviting.",
    "atmosphere": "Upbeat, nostalgic, lively, and incredibly friendly. A sense of youthful innocence and fun, set to the background hum of a jukebox.",
    "subject_expression": "A wide, genuine smile with bright, sparkling eyes. A slight tilt of the head, conveying friendliness and openness.",
    "subject_action": "One hand is holding a tall, frosted milkshake glass with a striped straw, perhaps mid-sip. The other hand is resting casually on the chrome counter or gesturing lightly. Body language is relaxed and happy.",
    "environmental_elements": "A perfect, whipped cream-topped milkshake with a cherry. Reflections of the diner's neon signs (if any) or bright lights on the chrome surfaces. A classic diner menu or napkin dispenser on the counter. Perhaps a faint 'Wurlitzer' logo on a distant jukebox."
  }
}
