# Act as AI Cloning #1 - RAW

Create a video an ultra realistic prompt with scenes and great lipsync (women who will lipped should be a business beautiful women, corprate) for kling.ai. Just a 5 seconds video and also create a separate 8s video:
